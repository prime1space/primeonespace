<?php
// public_html/api/test_path.php
header('Content-Type: text/plain');

echo "Current Directory: " . __DIR__ . "\n";
echo "Parent Directory: " . dirname(__DIR__) . "\n";

$vendor_path_root = dirname(__DIR__) . '/vendor/autoload.php';
$vendor_path_api = __DIR__ . '/vendor/autoload.php';

echo "Checking explicit path (Root): $vendor_path_root -> " . (file_exists($vendor_path_root) ? "EXISTS" : "MISSING") . "\n";
echo "Checking explicit path (API): $vendor_path_api -> " . (file_exists($vendor_path_api) ? "EXISTS" : "MISSING") . "\n";

echo "Checking db.php in Root: " . (file_exists(dirname(__DIR__) . '/db.php') ? "EXISTS" : "MISSING") . "\n";
echo "Checking db.php in API: " . (file_exists(__DIR__ . '/db.php') ? "EXISTS" : "MISSING") . "\n";

echo "Checking .env in Root: " . (file_exists(dirname(__DIR__) . '/.env') ? "EXISTS" : "MISSING") . "\n";

?>
