<?php
// backend/php/api/create-payment-intent.php

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../db.php';

// Load environment variables
$dotenv = \Dotenv\Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->load();

// Set Stripe API key
\Stripe\Stripe::setApiKey($_ENV['STRIPE_SECRET_KEY'] ?? '');

// Set headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    // Get request data
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Invalid request data');
    }
    
    $amount = $input['amount'] ?? 0; // Amount in LKR
    $bookingId = $input['bookingId'] ?? null;
    $userId = $input['userId'] ?? null;
    $email = $input['email'] ?? null;
    $description = $input['description'] ?? 'PrimeOne Space Booking';
    
    // Validate amount
    if ($amount <= 0) {
        throw new Exception('Invalid amount');
    }
    
    // Create Payment Intent
    $paymentIntent = \Stripe\PaymentIntent::create([
        'amount' => (int)($amount * 100), // Convert to cents (LKR 1500 = 150000 cents)
        'currency' => 'lkr',
        'automatic_payment_methods' => [
            'enabled' => true,
        ],
        'metadata' => [
            'booking_id' => $bookingId,
            'user_id' => $userId,
            'business' => 'PrimeOne Coworking Space',
            'location' => 'Vavuniya, Sri Lanka'
        ],
        'description' => $description,
        'receipt_email' => $email,
    ]);
    
    // Log the payment intent creation
    error_log("Payment Intent created: {$paymentIntent->id} for booking #{$bookingId}, amount: LKR {$amount}");
    
    // Return client secret
    echo json_encode([
        'success' => true,
        'clientSecret' => $paymentIntent->client_secret,
        'paymentIntentId' => $paymentIntent->id,
        'amount' => $amount,
        'currency' => 'lkr'
    ]);
    
} catch (\Stripe\Exception\ApiErrorException $e) {
    error_log('Stripe API Error: ' . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
} catch (Exception $e) {
    error_log('Payment Intent Error: ' . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
