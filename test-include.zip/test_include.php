<?php
// public_html/api/test_include.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "Starting diagnostic...\n";

// Try to include db.php from parent directory
$db_path = __DIR__ . '/../db.php';
echo "Trying to include: $db_path\n";

if (file_exists($db_path)) {
    echo "File exists! Including...\n";
    try {
        require_once $db_path;
        echo "SUCCESS: db.php included without crashing.\n";
        
        // Test Helper Functions
        echo "Checking helper functions:\n";
        echo "checkAdmin: " . (function_exists('checkAdmin') ? "YES" : "NO") . "\n";
        echo "getUserId: " . (function_exists('getUserId') ? "YES" : "NO") . "\n";
        
        // Test DB Connection
        if (isset($conn)) {
            echo "DB Connection: Verified.\n";
        } else {
            echo "DB Connection: Variable \$conn not found.\n";
        }
        
    } catch (Throwable $e) {
        echo "CRASH during include: " . $e->getMessage() . "\n";
        echo "File: " . $e->getFile() . " Line: " . $e->getLine() . "\n";
    }
} else {
    echo "ERROR: db.php not found at $db_path\n";
}
?>
